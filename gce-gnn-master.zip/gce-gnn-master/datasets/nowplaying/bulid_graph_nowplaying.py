# build_graph顾名思义应该是建立论文中描述的global-based图的。
import pickle
import argparse
import numpy as np
import random

parser = argparse.ArgumentParser()
# parser.add_argument('--dataset', default='diginetica', help='diginetica/Tmall/Nowplaying')
# ========= 修改内容 ============
parser.add_argument('--dataset', default='nowplaying', help='diginetica/Tmall/nowplaying/sample')
# diginetica数据集所需GPU内存较大，，使用sample数据集进行本机测试
# ========= 修改内容 ============
parser.add_argument('--sample_num', type=int, default=12)
opt = parser.parse_args()

dataset = opt.dataset
sample_num = opt.sample_num

# 读取所有会话数据
seq = pickle.load(open('all_train_seq.txt', 'rb'))

if dataset == 'diginetica':
    num = 43098
elif dataset == "retailrocket":
    num = 51448
elif dataset == "Tmall":
    num = 40728
elif dataset == "nowplaying":
    num = 60417
# ========= 修改内容 ============
elif dataset == "sample":
    num = 310
# ========= 修改内容 ============
else:
    num = 3

item_ids = set()
for session in seq:
    # 遍历会话中的每个元组（物品ID，时间戳）
    for item_id, _ in session:
        # 将物品ID添加到集合中，集合会自动处理重复的情况
        item_ids.add(item_id)

# 打印不同物品的数量
print(f"Total unique items in seq: {len(item_ids)}")

seq = [[(item_id, float(timestamp)) for item_id, timestamp in inner_list] for inner_list in seq]
# 假设seq是包含多个会话的列表，每个会话包含多个(item_id, timestamp)元组
all_timestamps = [timestamp for session in seq for _, timestamp in session]
min_timestamp = min(all_timestamps)
max_timestamp = max(all_timestamps)
time_segments = np.linspace(min_timestamp, max_timestamp, 4, endpoint=True)[1:]

# 初始化每个时间段和k值的邻居统计字典
# 每个时间段有自己的adj1字典数组，每个k值一个
# 3个时间段 x num个物品 x 3个k值的邻居关系
adj1_segments_k = [[[dict() for _ in range(3)] for _ in range(num)] for _ in range(3)]
#这里的结构解释如下：
# 最外层的列表：代表3个不同的时间段。
# 中间层的列表：代表每个时间段中的所有物品（num个）。
# 最内层的列表：对于每个物品，有3个字典，分别用于存储1阶、2阶和3阶邻居的出现次数。
# 例如，adj1_segments_k[0][5][2]将会是一个字典，表示在第一个时间段内，第6个物品的3阶邻居及其出现次数。
#
# 这样的结构允许你针对每个物品，分别在每个时间段内，统计它的1到3阶邻居的出现次数，为之后基于这些统计信息选出每个时间段内最频繁的邻居提供了基础。

# 伪代码，需要根据实际数据结构进行调整
for session in seq:
    for k in range(1, 4):  # k阶邻居
        for i in range(k, len(session)):  # 从k开始以确保有前置邻居
            current_item_id = session[i][0]  # 当前物品ID
            prev_item_id, prev_timestamp = session[i - k]  # 前一个物品ID和对应的时间戳

            # 确定前一个物品的时间戳所属的时间段
            segment_index = np.digitize([prev_timestamp], time_segments)[0]
            if segment_index == 3:
                segment_index = 2

            # 对应时间段和k值的前置邻居统计
            adj_dict = adj1_segments_k[segment_index][current_item_id][k - 1]
            if prev_item_id in adj_dict:
                adj_dict[prev_item_id] += 1
            else:
                adj_dict[prev_item_id] = 1

            # 同时更新后置邻居逻辑（原有代码）
            if i + k < len(session):
                next_item_id, next_timestamp = session[i + k]  # 下一个物品ID和对应的时间戳
                segment_index = np.digitize([next_timestamp], time_segments)[0]
                if segment_index == 3:
                    segment_index = 2
                adj_dict = adj1_segments_k[segment_index][current_item_id][k - 1]
                if next_item_id in adj_dict:
                    adj_dict[next_item_id] += 1
                else:
                    adj_dict[next_item_id] = 1

# 初始化最终的邻居列表和权重列表
adj_final = [[] for _ in range(num)]
weights_final = [[] for _ in range(num)]

for item in range(num):
    neighbors_all_segments = []
    weights_all_segments = []
    all_neighbors_dict = {}  # 全局邻居字典，存储所有邻居的权重
    # 初始每个时间段应选取的邻居数量
    neighbors_to_select = 4
    total_selected_neighbors = 0

    # 遍历每个时间段
    for segment in range(3):
        segment_neighbors_dict = {}

        # 汇总当前时间段内所有k阶邻居及其权重
        for k in range(3):
            adj_dict = adj1_segments_k[segment][item][k]
            for neighbor, weight in adj_dict.items():
                if neighbor in segment_neighbors_dict:
                    segment_neighbors_dict[neighbor] += weight
                else:
                    segment_neighbors_dict[neighbor] = weight
                # 更新全局字典
                if neighbor in all_neighbors_dict:
                    all_neighbors_dict[neighbor] += weight
                else:
                    all_neighbors_dict[neighbor] = weight

        # 按权重对邻居进行排序，选取当前段应选择的数量
        sorted_neighbors_weights = sorted(segment_neighbors_dict.items(), key=lambda x: x[1], reverse=True)[:neighbors_to_select]

        # 更新实际选取的邻居数量
        actually_selected = len(sorted_neighbors_weights)
        total_selected_neighbors += actually_selected

        # 更新下一个时间段应选取的邻居数量
        neighbors_to_select = 4 + (neighbors_to_select - actually_selected)

        # 将这些邻居的ID和权重分别添加到列表中
        neighbors_all_segments.extend([n[0] for n in sorted_neighbors_weights])
        weights_all_segments.extend([n[1] for n in sorted_neighbors_weights])

    # 如果到了最后总选取的邻居不足12个，补足至12个
    if total_selected_neighbors < 12:
        needed_neighbors = 12 - total_selected_neighbors
        if total_selected_neighbors > 0:  # 确保已有邻居非空
            neighbors_all_segments.extend([0] * needed_neighbors)
            weights_all_segments.extend([0] * needed_neighbors)
        else:
            # 如果一个邻居都没选出来，用自身和59个0填充
            neighbors_all_segments.extend([item] + [0] * 11)
            weights_all_segments.extend([0] * 12)  # 假设自身的权重也是0

    # 保存每个物品的邻居和权重信息
    adj_final[item] = neighbors_all_segments
    weights_final[item] = weights_all_segments

pickle.dump(adj_final, open('adj_final_12.pkl', 'wb'))
pickle.dump(weights_final, open('weights_final_12.pkl', 'wb'))

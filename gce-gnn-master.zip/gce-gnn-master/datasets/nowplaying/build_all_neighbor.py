import pickle
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', default='Nowplaying', help='diginetica/Tmall/Nowplaying')
parser.add_argument('--sample_num', type=int, default=12)  # 用于限制每个节点保存的最大邻居数量
opt = parser.parse_args()

dataset = opt.dataset
sample_num = opt.sample_num

# 加载序列数据，每个序列项格式为 (item_id, timestamp)
seq = pickle.load(open('all_train_seq.txt', 'rb'))

# 根据数据集设定不同的物品数量
if dataset == 'diginetica':
    num = 43098
elif dataset == "Tmall":
    num = 40728
elif dataset == "Nowplaying":
    num = 60417
else:
    num = 3

# 已有代码片段，构建并排序邻居列表
neighbors = [set() for _ in range(num)]

# 构建邻居列表
for session in seq:
    for k in range(1, 2):  # 查找从1到3阶邻居
        for j in range(len(session) - k):
            neighbors[session[j]].add(session[j+k])
            neighbors[session[j+k]].add(session[j])

# 将集合转换为列表
for i in range(num):
    neighbors[i] = list(neighbors[i])

# 计算最大邻居数量
max_neighbors = max(len(neighbor) for neighbor in neighbors)
print(max_neighbors)
print('neighbors:', neighbors[:10])  # 打印前10个节点的邻居列表





# 保存处理后的数据
pickle.dump(neighbors, open('all_neighbors.pkl', 'wb'))

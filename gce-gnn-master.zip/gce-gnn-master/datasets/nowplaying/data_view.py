import pickle
from io import StringIO

import pandas as pd
file_content = 'nowplaying.csv'
df = pd.read_csv(file_content, sep='\t')
# 假设data是你的DataFrame
# 首先检查列名是否存在
# 将时间戳（假设它是Unix时间戳）转换为日期时间格式
df['Time'] = pd.to_datetime(df['Time'], unit='s')

# 添加一个新列，表示年份和月份
df['YearMonth'] = df['Time'].dt.to_period('M')

# 按年份和月份统计点击次数
clicks_per_month = df.groupby('YearMonth').size()

print(clicks_per_month)
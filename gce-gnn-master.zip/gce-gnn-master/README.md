# GCE-GNN

### 介绍

"Global Context Enhanced Graph Neural Network for Session-based Recommendation"，SIGIR-2020，详细中文注释版代码。官方代码地址：https://github.com/CCIIPLab/GCE-GNN
import numpy as np
import torch
from torch.utils.data import Dataset
import datetime

# 和SR-GNN类似的方式划分训练集和测试集
def split_validation(train_set, valid_portion):
    train_set_x, train_set_y = train_set
    n_samples = len(train_set_x)
    sidx = np.arange(n_samples, dtype='int32')
    np.random.shuffle(sidx)
    n_train = int(np.round(n_samples * (1. - valid_portion)))
    valid_set_x = [train_set_x[s] for s in sidx[n_train:]]
    valid_set_y = [train_set_y[s] for s in sidx[n_train:]]
    train_set_x = [train_set_x[s] for s in sidx[:n_train]]
    train_set_y = [train_set_y[s] for s in sidx[:n_train]]

    return (train_set_x, train_set_y), (valid_set_x, valid_set_y)



def create_session_neighbors(data):
    all_sessions_neighbors = []
    all_count = []
    max_neighbors_count = {}  # 字典存储每个物品的最大邻居数
    max = 0
    for session in data:
        neighbors = {}
        item_counts = {}  # 新增字典记录每个物品的出现次数
        session_length = len(session)
        for i in range(session_length):
            item = session[i]
            if item not in neighbors:
                neighbors[item] = []
            if item not in item_counts:
                item_counts[item] = 0
            item_counts[item] += 1  # 更新物品出现次数

            if item == 0:
                neighbors[item] = [0]
                continue

            if i > 0 and session[i - 1] != 0:
                neighbors[item].append(session[i - 1])

            if i < session_length - 1 and session[i + 1] != 0:
                neighbors[item].append(session[i + 1])

        # 限制每个物品的邻居数量为10，并进行填充
        # for item, neighbor_list in neighbors.items():
        #     if item == 0:
        #         continue
        #     neighbors[item].append(item)  # 自己也作为邻居
        for item, neighbor_list in neighbors.items():
            current_length = len(neighbor_list)
            if current_length > 10:
                neighbors[item] = neighbor_list[-9:]  # 选择最后9个邻居
                neighbors[item] = [item] + neighbors[item]  # 自己也作为邻居
            else:
                neighbors[item] = [item] + neighbors[item]  # 自己也作为邻居
                neighbors[item] += [0] * (10 - current_length + 1)  # 填充0以保证总共10个邻居
                # 更新每个物品的最大邻居数
        item_counts[0] = 0
        all_count.append(item_counts)
        all_sessions_neighbors.append(neighbors)
    print('max:', max)
    return all_sessions_neighbors,all_count


# 对于输入数据train_data、valid_data、test_data进行处理
def handle_data(inputData, train_len=None):
    len_data = [len(nowData) for nowData in inputData]
    if train_len is None:
        max_len = max(len_data)
    else:
        max_len = train_len

    # Initialize lists to store the padded sequences, masks, and last item IDs
    # Pad the sequences if necessary, while collecting the last item for target2
    us_pois = [list(reversed(upois)) + [0] * (max_len - le) if le < max_len else list(reversed(upois[-max_len:]))
               for upois, le in zip(inputData, len_data)]
    us_pois1 = [upois + [0] * (max_len - le) if le < max_len else upois[-max_len:]
               for upois, le in zip(inputData, len_data)]
    us_msks = [[1] * le + [0] * (max_len - le) if le < max_len else [1] * max_len
               for le in len_data]

    neighbor,count = create_session_neighbors(us_pois1)

    #print('us_pois:', us_pois)
    return us_pois, us_msks, max_len, neighbor,count


def handle_all_adj(adj_list, n_entity):
    # Determine the longest list of neighbors
    mask = [[] for _ in range(n_entity)]
    max_neighbors = max(len(neighbors) for neighbors in adj_list if neighbors is not None)
    print('max_neighbors:', max_neighbors)

    # Fill each node's neighbor list to the max length with None
    for i in range(n_entity):
        if adj_list[i] is not None:
            original_length = len(adj_list[i])
            adj_list[i].extend([0] * (max_neighbors - original_length))
            mask[i] = [1] * original_length + [0] * (max_neighbors - original_length)
        else:
            adj_list[i] = [0] * max_neighbors
            mask[i] = [0] * max_neighbors

    return adj_list, mask


# 这个函数在main.py中调用
# 输入分别是adj:item的邻居,num_node:item的总个数，opt.n_sample_all:采样邻居个数，num:邻居出现的次数
def handle_adj(adj_dict, n_entity, sample_num, num_dict=None):
    """
    根据指定的采样个数处理数据，只对sample_num个邻居进行采样

    :param adj_dict: item的邻接映射，即itemId -> itemIds
    :param n_entity: item的总个数
    :param sample_num: 采样邻居个数
    :param num_dict: 邻居出现的次数
    :return:
    """
    # 为所有的item建立一个邻居关系的矩阵adj_entity及出现次数的矩阵num_entity，初始化
    adj_entity = np.zeros([n_entity, sample_num], dtype=np.int64)
    num_entity = np.zeros([n_entity, sample_num], dtype=np.int64)
    # 计算邻居关系的矩阵adj_entity及出现次数的矩阵num_entity的值
    for entity in range(1, n_entity):
        # 当前项目 entity 的邻居集合
        neighbor = list(adj_dict[entity])
        # 邻居对应的权重集合
        neighbor_weight = list(num_dict[entity])
        # 邻居个数
        n_neighbor = len(neighbor)

        if n_neighbor == 0:
            continue
        # 采样，如果邻居个数大于指定的采样个数，则从所有邻居中随机采集sample_num个item；否则，则可重复的从邻居中采样sample_num个item。这可能带有噪声
        if n_neighbor >= sample_num:
            # replace = False 不可重复采样；replace=True 可重复采样
            sampled_indices = np.random.choice(list(range(n_neighbor)), size=sample_num, replace=False)
        else:
            sampled_indices = np.random.choice(list(range(n_neighbor)), size=sample_num, replace=True)
        # 更新当前item（entity）的邻居集合及对应的权重
        adj_entity[entity] = np.array([neighbor[i] for i in sampled_indices])
        num_entity[entity] = np.array([neighbor_weight[i] for i in sampled_indices])

    return adj_entity, num_entity


# 继承Dataset主要是为了便于使用DataLoader加载数据
class Data(Dataset):
    def __init__(self, data, opt, train_len=None):
        inputs, mask, max_len,neighbor,count = handle_data(data[0], train_len)

        self.inputs = np.asarray(inputs)
        # self.timestamps = np.asarray(data[2])
        self.targets = np.asarray(data[1])
        self.mask = np.asarray(mask)
        # 会话的个数
        self.length = len(data[0])
        self.max_len = max_len
        self.dataset = opt.dataset
        self.neighbor = neighbor
        self.count = count




    def __getitem__(self, index):
        # 根据索引index的值取出对应的会话序列u_input, mask, 以及target，和SR-GNN类似
        u_input, mask,target,neighbor,count = self.inputs[index],self.mask[index],self.targets[index],self.neighbor[index],self.count[index]
        #
        # print('u_input:',u_input)
        # session_neighbors = self.create_session_neighbors([u_input])
        # print('session_neighbors:',session_neighbors)

        max_n_node = self.max_len
        node = np.unique(u_input)
        # 去重并填充0后的会话序列
        items = node.tolist() + (max_n_node - len(node)) * [0]

        alias_inputs = [np.where(node == i)[0][0] for i in u_input]
        N = 10  # 根据实际情况调整
        # 初始化邻居矩阵，大小为L x N
        neighbor_matrix = np.zeros((len(u_input), N), dtype=int)
        count_matrix = np.zeros((len(u_input), N), dtype=int)

        # 填充邻居矩阵
        neighbor_mask = np.zeros((len(u_input), N), dtype=int)

        # 填充邻居矩阵和邻居掩码矩阵
        for i, item in enumerate(u_input):
            # 获取当前物品的邻居列表，如果物品在字典中没有对应邻居则使用空列表
            current_neighbors = neighbor.get(item, [])

            # 限制邻居数量，不足的部分用0填充
            for j in range(min(N, len(current_neighbors))):
                if current_neighbors[j] == 0:
                    break
                else:
                    neighbor_matrix[i][j] = current_neighbors[j]
                    count_matrix[i][j] = count.get(current_neighbors[j])
                    neighbor_mask[i][j] = 1  # 对应位置上存在有效邻居

        # 返回当前会话序列对应的alias_inputs、邻居矩阵、去重并填充0之后的会话序列、会话掩码、会话目标值、未去重的会话序列

        return [torch.tensor(alias_inputs), torch.tensor(items),torch.tensor(mask), torch.tensor(target),torch.tensor(u_input),torch.tensor(neighbor_matrix),torch.tensor(neighbor_mask),torch.tensor(count_matrix)]

    def __len__(self):
        return self.length

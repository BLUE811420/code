import time
import argparse
import pickle
from model import *
from utils import *


def init_seed(seed=None):
    if seed is None:
        seed = int(time.time() * 1000 // 1000)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


parser = argparse.ArgumentParser()
parser.add_argument('--dataset', default='diginetica', help='yoochoose/yoochoose1_4/diginetica/nowplaying/Tmall/sample/retailrocket')
parser.add_argument('--hiddenSize', type=int, default=256)
parser.add_argument('--epoch', type=int, default=20)
parser.add_argument('--activate', type=str, default='relu')
parser.add_argument('--n_sample_all', type=int, default=12)
parser.add_argument('--all_neighbor', type=int, default=0)
parser.add_argument('--n_sample', type=int, default=12)
parser.add_argument('--batch_size', type=int, default=256)
parser.add_argument('--lr', type=float, default=0.001, help='learning rate.')
parser.add_argument('--lr_dc', type=float, default=0.1, help='learning rate decay.')
parser.add_argument('--lr_dc_step', type=int, default=3, help='the number of steps after which the learning rate decay.')
parser.add_argument('--l2', type=float, default=1e-5, help='l2 penalty ')
parser.add_argument('--n_iter', type=int, default=1)                                    # [1, 2]
parser.add_argument('--dropout_gcn', type=float, default=0, help='Dropout rate.')       # [0, 0.2, 0.4, 0.6, 0.8]
parser.add_argument('--dropout_local', type=float, default=0, help='Dropout rate.')     # [0, 0.5]
parser.add_argument('--dropout_global', type=float, default=0.4, help='Dropout rate.')
parser.add_argument('--validation', action='store_true', help='validation',default=False)
parser.add_argument('--valid_portion', type=float, default=0.1, help='split the portion')
parser.add_argument('--alpha', type=float, default=0.2, help='Alpha for the leaky_relu.')
parser.add_argument('--step', type=int, default=2, help='layer num for gcn.')
parser.add_argument('--d_state', type=int, default=8, help='layer num for gcn.')
parser.add_argument('--d_conv', type=int, default=2, help='layer num for gcn.')
parser.add_argument('--expand', type=int, default=2, help='layer num for gcn.')
parser.add_argument('--patience', type=int, default=3)
parser.add_argument('--device', type=str, default='cuda:0')
parser.add_argument('--temperature', type=float, default=0.07)
parser.add_argument('--beta', type=float, default=0.2)
parser.add_argument('--item_cl_loss_weight', type=float, default=1)
parser.add_argument('--sampled_item_size', type=int, default=2)
parser.add_argument('--use_item_cl_loss', action='store_true', default=True)

opt = parser.parse_args()

def main():
    init_seed(42)

    if opt.dataset == 'diginetica':
        num_node = 43098
        opt.n_iter = 1
        opt.step = 1 #gcn还得等于2
        opt.dropout_gcn = 0.4
        opt.dropout_local = 0.0
        opt.dropout_global = 0.2
        opt.d_state = 8
        opt.d_conv = 2
        opt.expand = 2
        opt.activate = 'relu'
        opt.all_neighbor = 321
        opt.temperature = 0.07 # 不能搞大
        opt.beta = 0.2
    elif opt.dataset == 'retailrocket':
        num_node = 36969
        opt.n_iter = 1
        opt.step = 1
        opt.dropout_gcn = 0.4
        opt.dropout_local = 0.6
        opt.dropout_global = 0.6
        opt.d_state = 8
        opt.d_conv = 2
        opt.expand = 2
    elif opt.dataset == 'yoochoose/yoochoose1_4':
        num_node = 37484
        opt.batch_size = 100
        opt.n_iter = 1
        opt.step = 1
        opt.dropout_global = 0.4
        opt.dropout_gcn = 0.6
        opt.dropout_local = 0.6
        opt.d_state = 8
        opt.d_conv = 2
        opt.expand = 2
    elif opt.dataset == 'yoochoose/yoochoose1_64':
        num_node = 37484
        opt.n_iter = 1
        opt.step = 1
        opt.hiddenSize = 256
        opt.batch_size = 100
        opt.dropout_gcn = 0.0
        opt.dropout_local = 0.0
        opt.dropout_global = 0.4
        opt.d_state = 8
        opt.d_conv = 2
        opt.expand = 2
        opt.all_neighbor = 710
        opt.temperature = 0.07
        opt.beta = 0.2
    elif opt.dataset == 'nowplaying':
        num_node = 60417
        opt.hiddenSize = 100
        opt.batch_size = 256
        opt.n_iter = 1
        opt.step = 1
        opt.dropout_gcn = 0.4
        opt.dropout_local = 0.6
        opt.dropout_global = 0.6
        opt.d_state = 8
        opt.d_conv = 2
        opt.expand = 2

    elif opt.dataset == 'ml-1m':
        num_node = 3409
        opt.n_iter = 2
        opt.dropout_gcn = 0.2
        opt.dropout_local = 0.0

    elif opt.dataset == 'Tmall':
        num_node = 40728
        opt.n_iter = 1
        opt.step = 1
        opt.dropout_gcn = 0.0
        opt.dropout_local = 0.0
        opt.dropout_global = 0.2
        opt.d_state = 8
        opt.d_conv = 2
        opt.expand = 2
        opt.all_neighbor = 804
    else:
        num_node = 310

    train_data = pickle.load(open('datasets/' + opt.dataset + '/train.txt', 'rb'))
    if opt.validation:
        train_data, valid_data = split_validation(train_data, opt.valid_portion)
        test_data = valid_data
    else:
        test_data = pickle.load(open('datasets/' + opt.dataset + '/test.txt', 'rb'))

    # 加载item的邻居信息以及对应出现的次数，读取train_data,和test_data
    # 注意这里的opt.n_sample_all与opt.n_sample不同（即可以在计算邻居的时候多包括一些邻居，后面构建邻居矩阵的时候可再进行随机选取一部分）
    # 不过论文中取的值相同，即选多少邻居就用多少邻居
    # train_all_session = pickle.load(open('datasets/' + opt.dataset + '/all_train_seq.txt', 'rb'))
    ## print(train_all_session)
    #adj = pickle.load(open('datasets/' + opt.dataset + '/adj_final_12.pkl', 'rb'))
    all_adj = pickle.load(open('datasets/' + opt.dataset + '/all_neighbors.pkl', 'rb'))
    all_adj,mask = handle_all_adj(all_adj, num_node)
    #num = pickle.load(open('datasets/' + opt.dataset + '/weights_final_12.pkl', 'rb'))

    #adj_prenode = pickle.load(open('datasets/' + opt.dataset + '/pre_node_adj_12.pkl', 'rb'))
    #num_prenode = pickle.load(open('datasets/' + opt.dataset + '/pre_node_num_12.pkl', 'rb'))
    train_data = Data(train_data,opt)
    test_data = Data(test_data, opt)

    # 输入是adj:item的邻居，itemId->items；num_node:item的总个数；opt.n_sample_all:采样邻居个数；num:邻居出现的次数
    # adj_prenode, num_prenode = handle_adj(adj_prenode, num_node, opt.n_sample_all, num_prenode)
    model = trans_to_cuda(CombineGraph(opt, num_node, all_adj, mask))
    cl_loss_function = nn.CrossEntropyLoss()
    # print(model)
    print(opt)
    start = time.time()
    best_result = [0, 0, 0, 0]
    best_epoch = [0, 0, 0, 0]
    bad_counter = 0
    save_path = 'datasets/' + opt.dataset + 'best_model.pth'
    for epoch in range(opt.epoch):
        print('-------------------------------------------------------')
        print('epoch: ', epoch)
        hit_20, mrr_20, hit_10, mrr_10 = train_test(model, train_data, test_data,cl_loss_function=cl_loss_function,
                             use_item_cl_loss=opt.use_item_cl_loss,
                             sampled_item_size=opt.sampled_item_size,
                             temperature=opt.temperature,
                             item_cl_loss_weight=opt.item_cl_loss_weight)

        flag = 0
        # 更新hit@20和mrr@20的最佳结果
        if hit_20 >= best_result[0]:
            best_result[0] = hit_20
            best_epoch[0] = epoch
            flag = 1

        if mrr_20 >= best_result[1]:
            best_result[1] = mrr_20
            best_epoch[1] = epoch
            flag = 1
        # 更新hit@10和mrr@10的最佳结果
        if hit_10 >= best_result[2]:
            best_result[2] = hit_10
            best_epoch[2] = epoch
            flag = 1
        if mrr_10 >= best_result[3]:
            best_result[3] = mrr_10
            best_epoch[3] = epoch
            flag = 1

        print('Current Result:')
        print('\tRecall@20:\t%.4f\tMRR@20:\t%.4f' % (hit_20, mrr_20))
        print('\tRecall@10:\t%.4f\tMRR@10:\t%.4f' % (hit_10, mrr_10))

        print('Best Result:')
        print('\tRecall@20:\t%.4f\tMRR@20:\t%.4f\tEpoch:\t%d,\t%d' % (
            best_result[0], best_result[1], best_epoch[0], best_epoch[1]))
        print('\tRecall@10:\t%.4f\tMRR@10:\t%.4f\tEpoch:\t%d,\t%d' % (
            best_result[2], best_result[3], best_epoch[2], best_epoch[3]))
        if flag == 1:
            torch.save(model, save_path)
            print(f"Model saved to {save_path} at epoch {epoch} with results: hit@20={hit_20}, mrr@20={mrr_20}, hit@10={hit_10}, mrr@10={mrr_10}")
        bad_counter += 1 - flag
        if bad_counter >= opt.patience:
            break

    print('-------------------------------------------------------')
    end = time.time()
    print("Run time: %f s" % (end - start))
if __name__ == '__main__':
    main()
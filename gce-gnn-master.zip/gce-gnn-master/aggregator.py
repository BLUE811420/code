import math
import pdb

import torch
import torch.nn as nn
from torch.nn import Parameter
import torch.nn.functional as F
import numpy


# from mamba_ssm import Mamba
#
#
#
# class Mambalayer(nn.Module):
#     def __init__(self, dim, opt, d_state=16, d_conv=2,expand=2):
#         super(Mambalayer,self).__init__()
#         #self.item_embedding = nn.Embedding(n_node, dim)
#         self.dim = dim
#         self.opt = opt
#         # self.d_state = d_state
#         # self.d_conv = d_conv
#         # self.expand = expand
#         self.num_layers = 1
#         self.mamba = Mamba(
#             d_model=dim,
#             d_state=opt.d_state,
#             d_conv=opt.d_conv,
#             expand=opt.expand
#         )
#         self.dropout = nn.Dropout(0.2)
#         self.LayerNorm = nn.LayerNorm(dim, eps=1e-12)
#         self.ffn = FeedForward(dim=dim, inner_size=dim * 4, dropout=0.2)
#         #self.w2 = nn.Parameter(torch.Tensor(self.dim, 1))
#     def forward(self, item_seq):
#
#         for i in range(self.num_layers):
#
#             item_seq = self.mamba(item_seq)
#             hidden_states = self.LayerNorm(self.dropout(item_seq))
#             hidden_states = self.ffn(hidden_states)
#             item_seq = hidden_states
#
#         return item_seq

class FeedForward(nn.Module):
    def __init__(self, dim, inner_size, dropout=0.2):
        super().__init__()
        self.w_1 = nn.Linear(dim, inner_size)
        self.w_2 = nn.Linear(inner_size, dim)
        self.activation = nn.GELU()
        self.dropout = nn.Dropout(dropout)
        self.LayerNorm = nn.LayerNorm(dim, eps=1e-12)

    def forward(self, input_tensor):
        hidden_states = self.w_1(input_tensor)
        hidden_states = self.activation(hidden_states)
        hidden_states = self.dropout(hidden_states)

        hidden_states = self.w_2(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.LayerNorm(hidden_states + input_tensor)

        return hidden_states



class Aggregator(nn.Module):
    def __init__(self, batch_size, dim, dropout, act, name=None):
        super(Aggregator, self).__init__()
        self.dropout = dropout
        self.act = act
        self.batch_size = batch_size
        self.dim = dim

    def forward(self):
        pass


# 从model.py中知道这里 forward 函数的输入分别是会话中所有item的embedding：hidden， item的邻居item矩阵：adj，掩码：mask_item
class LocalAggregator(nn.Module):
    def __init__(self, dim, alpha, dropout=0., name=None):
        super(LocalAggregator, self).__init__()
        self.dim = dim
        self.dropout = dropout

        # 四种边对应的关系向量
        self.a_0 = nn.Parameter(torch.Tensor(self.dim, 1))
        self.a_1 = nn.Parameter(torch.Tensor(self.dim, 1))
        self.a_2 = nn.Parameter(torch.Tensor(self.dim, 1))
        self.a_3 = nn.Parameter(torch.Tensor(self.dim, 1))
        # 偏置项
        self.bias = nn.Parameter(torch.Tensor(self.dim))

        self.leakyrelu = nn.LeakyReLU(alpha)

    def forward(self, hidden, adj, mask_item=None):
        h = hidden  # batch_size*seq_size**hidden_size
        batch_size = h.shape[0]
        # N是seq_len
        N = h.shape[1]

        # 这里是公式(7)中点积部分：h_{v_i} dot h_{v_j}
        # Pytorch中的repeat函数是将tensor对应的维度扩大指定倍数，这里是第0、1、2维分别扩大1、1、N倍变为batch_size*seq_size*(N*hidden_size)
        # Pytorch 中 * 表示矩阵对应位置相乘；这一步的计算可以尝试一个简单的tensor模拟。辅助理解。所有hi与hj两两相乘得到一个batch_size*N*N*self.dim的结果
        a_input = (h.repeat(1, 1, N).view(batch_size, N * N, self.dim) * h.repeat(1, N, 1)) \
            .view(batch_size, N, N, self.dim)

        # 对a_input进行四种不同的线性映射表示四种类型的边，对应公式（7）的a_rij_T(h_{v_i} dot h_{v_j})
        e_0 = torch.matmul(a_input, self.a_0)
        e_1 = torch.matmul(a_input, self.a_1)
        e_2 = torch.matmul(a_input, self.a_2)
        e_3 = torch.matmul(a_input, self.a_3)

        # 进行LeakyReLU激活，完成公式(7)其余部分
        e_0 = self.leakyrelu(e_0).squeeze(-1).view(batch_size, N, N)
        e_1 = self.leakyrelu(e_1).squeeze(-1).view(batch_size, N, N)
        e_2 = self.leakyrelu(e_2).squeeze(-1).view(batch_size, N, N)
        e_3 = self.leakyrelu(e_3).squeeze(-1).view(batch_size, N, N)

        # 创建一个值全为-9e15的矩阵，如果adj中的值为1，则让alpha中对应的值为e_0中对应的值，否则alpha中对应的值为-9e15
        mask = -9e15 * torch.ones_like(e_0)
        alpha = torch.where(adj.eq(1), e_0, mask)
        # 这样alpha即由1和-9e15两个值组成，若其中的值等于2，则alpha中对应的值为e_1中对应的值，否则保持不变，3和4同理
        alpha = torch.where(adj.eq(2), e_1, alpha)
        alpha = torch.where(adj.eq(3), e_2, alpha)
        alpha = torch.where(adj.eq(4), e_3, alpha)
        # 对alpha进行softmax操作，得到注意力分数
        alpha = torch.softmax(alpha, dim=-1)

        # 公式(9)加权求和，得到会话级项目表示
        output = torch.matmul(alpha, h)
        return output


import torch
import torch.nn as nn

class MyGRUCell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(MyGRUCell, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        # 参数初始化
        self.W_z = nn.Parameter(torch.randn(hidden_size, 2 * input_size))  # 修改
        self.U_z = nn.Parameter(torch.randn(hidden_size, hidden_size))
        self.b_z = nn.Parameter(torch.zeros(hidden_size))

        self.W_r = nn.Parameter(torch.randn(hidden_size, input_size))  # 修改
        self.U_r = nn.Parameter(torch.randn(hidden_size, hidden_size))
        self.b_r = nn.Parameter(torch.zeros(hidden_size))

        self.W_h = nn.Parameter(torch.randn(hidden_size, input_size))  # 修改
        self.U_h = nn.Parameter(torch.randn(hidden_size, hidden_size))
        self.b_h = nn.Parameter(torch.zeros(hidden_size))
        self.W_u = nn.Parameter(torch.randn(hidden_size, hidden_size))  # 修改
        self.W_s = nn.Parameter(torch.randn(hidden_size, hidden_size))  # 修改

    def forward(self, x, self_vectors, h_prev=None):
        batch_size, seq_len, _ = x.shape
        if h_prev is None:
            h_prev = torch.zeros(batch_size, self.hidden_size, device=x.device)

        h_next = h_prev
        outputs = []
        for t in range(seq_len):
            xt = x[:, t, :]
            self_vectors1 = self_vectors[:, t, :]
            # 计算更新门和重置门
            z = torch.sigmoid(torch.matmul(torch.cat([xt, self_vectors1], -1), self.W_z.T) + torch.matmul(h_next, self.U_z.T) + self.b_z)
            r = torch.sigmoid(torch.matmul(xt, self.W_r.T) + torch.matmul(h_next, self.U_r.T) + self.b_r)

            # 拼接修改后的hidden state与self_vectors进行hidden state的更新计算
            combined_hr = r * h_next  # 使用r调整后的hidden state与self_vectors拼接,明天再试一下这个地方cat中心节点试一下
            #combined_hr = torch.cat([combined_hr, self_vectors[:, t, :]], -1)
            #combined_hr = torch.cat([combined_hr, self_vectors[:, t, :]], -1)
            h_tilde = torch.tanh(torch.matmul(xt, self.W_u.T) + torch.matmul(combined_hr, self.W_h.T) + self.b_h) # h_tilde是当前时刻的候选隐藏状态

            # 更新hidden state
            h_next = (1 - z) * h_tilde + z * h_next
            outputs.append(h_next.unsqueeze(1))

        outputs = torch.cat(outputs, dim=1)
        return outputs, h_next

class GatedFusion(nn.Module):
    def __init__(self, feature_dim):
        super(GatedFusion, self).__init__()
        self.feature_dim = feature_dim
        self.gate_weight = nn.Parameter(torch.Tensor(2*feature_dim, feature_dim))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.gate_weight, a=math.sqrt(5))

    def forward(self, x, y):
        # 平均每个时间步的特征
        x_mean = torch.mean(x, dim=1, keepdim=True)
        y_mean = torch.mean(y, dim=1, keepdim=True)
        combined_mean = torch.cat((x_mean, y_mean), dim=-1)

        # 计算全局门控信号
        gate_signal = torch.sigmoid(torch.matmul(combined_mean, self.gate_weight))
        gate_signal = gate_signal.expand_as(x)  # 扩展门控信号匹配原始输入维度

        # 应用门控信号
        z = gate_signal * x + (1 - gate_signal) * y
        return z

class GlobalAggregator(nn.Module):
    def __init__(self, dim, dropout,opt, act=torch.relu, name=None):
        super(GlobalAggregator, self).__init__()
        self.dropout = dropout
        self.act = act
        self.dim = dim
        self.opt = opt
        # 对应公式2中的W1，这里+1是因为公式2中拼接了一个Wij
        self.w_1 = nn.Parameter(torch.Tensor(self.dim + 1, self.dim))
        # 对应公式2中的q_1^T
        self.w_2 = nn.Parameter(torch.Tensor(self.dim, 1))
        self.w_3 = nn.Parameter(torch.Tensor(2 * self.dim, self.dim))
        self.gate = GatedFusion(self.dim)
        self.gru1 = nn.GRU(self.dim, self.dim, batch_first=True)
        self.gru = MyGRUCell(self.dim, self.dim)
        self.bias = nn.Parameter(torch.Tensor(self.dim))
        self.device = self.opt.device
        self.to(self.opt.device)
    def forward(self, self_vectors, neighbor_vector, batch_size, masks,neighbor_weight, extra_vector=None):
        """
        计算用户的全局偏好，并输出对应的embedding
        :param self_vectors: 输入会话序列的初始embedding
        :param neighbor_vector: 输入会话序列的邻居结点对应的embedding，shape为：batch_size*seq_len*sample_num*self.dim
        :param batch_size: 训练时的batch_size，默认为100
        :param masks: 会话序列掩码，但是没有用到
        :param neighbor_weight: 和邻居结点之间边的权重，shape为batch_size*seq_len*sample_num
        :param extra_vector: 传shape为batch_size*seq_len*self.dim的会话序列均值，对应公式2中的s
        :return: 节点的全局级表示
        """
        # ======== 断点调试 =======
        # pdb.set_trace()
        # ======== 断点调试 =======
        self_vectors = self_vectors.to(self.device)
        # print(self_vectors.shape)
        self_vectors_reshape = self_vectors.unsqueeze(2).repeat(1, 1, neighbor_vector.shape[2], 1)
        self_vectors_reshape = self_vectors_reshape.view(batch_size * neighbor_vector.shape[1], neighbor_vector.shape[2],self.dim)
        neighbor_vector = neighbor_vector.to(self.device)

        neighbor_vector_reshaped = neighbor_vector.view(batch_size * neighbor_vector.shape[1], neighbor_vector.shape[2],self.dim)
        # #print(neighbor_vector_reshaped)
        # #应用 GRU
        # gru_output, _ = self.gru(neighbor_vector_reshaped, self_vectors_reshape)
        # # print(gru_output.shape)
        # # print(gru_output.shape)
        # #将 GRU 输出的形状从(batch_size * seq_len, sample_num, hidden_dim)调整回(batch_size, seq_len, sample_num, hidden_dim)
        # gru_output_reshaped = gru_output.view(batch_size, -1, neighbor_vector.shape[2], self.dim)
        #print(gru_output_reshaped)
        # neighbor_vector = neighbor_vector * masks
        #print(masks)
        #print(gru_output_masked)
        # print(neighbor_vector)
        # print(gru_output_masked)
        # print(gru_output_reshaped)
        if extra_vector is not None:
            # 这里是公式（2），让s \cdot h_{v_j}，之后再与边权w_{ij}做拼接，之后通过一个线性映射得到alpha=\pi(v_i,v_j)\
            neighbor_weight = neighbor_weight.unsqueeze(-1)
            cat1 = self_vectors.unsqueeze(2).repeat(1, 1, neighbor_vector.shape[2], 1)
            cat2 = neighbor_vector
            alpha = torch.matmul(torch.cat([cat1*cat2, neighbor_weight], -1), self.w_1).squeeze(-1)
            # 公式2的激活部分
            alpha = F.leaky_relu(alpha, negative_slope=0.2)
            # 公式2的q_1^T进行线性映射部分
            alpha = torch.matmul(alpha, self.w_2).squeeze(-1)
            alpha = torch.where(masks.bool(), alpha, torch.tensor(-9e15).to(self.device))
            # 公式4进行权重归一化
            alpha = torch.softmax(alpha, -1).unsqueeze(-1)
            # print(alpha)
            # 公式1进行加权求和
            neighbor_vector = torch.sum(alpha * neighbor_vector, dim=-2)
            # 均值池化
        #neighbor_vector = torch.mean(neighbor_vector, dim=2)
        # self_vectors = F.dropout(self_vectors, 0.5, training=self.training)
        # 公式5中的拼接部分，聚合得到的邻居信息与更新前的item向量进行拼接，激活再线性映射，从而得到outout
        output = self.gate(self_vectors, neighbor_vector)
        #output = torch.cat([self_vectors, neighbor_vector], -1)
        # # # output = F.dropout(output, self.dropout, training=self.training)
        # # # 线性变换
        #output = torch.matmul(output, self.w_3)
        # ======== 断点调试 =======
        # pdb.set_trace()
        # ======== 断点调试 =======
        # 重新调整维度为batch_size*seq_len*hidden_size
        #output = output.view(batch_size, -1, self.dim)
        # 公式5的激活部分
        #output = self.act(output)
        # 返回节item的全局级表示，大小为batch_size*seq_len*hidden_size
        return output

